# Do Women Need to Earn Self-Love? — Interactive Research Exhibit

一个可以 **直接打开、直接课堂展示，也可以发布到 GitHub Pages** 的纯静态可视化网站。网页默认英文；点击右上角的「中文 / EN」可切换主要界面的语言。案例详情一直保留原始中文引文和英文译文。

## 文件结构

- `index.html` — 网页入口
- `styles.css` — 视觉设计、响应式布局
- `data.js` — 19 条匿名研究记录与六项编码数据；可以直接修改
- `script.js` — 语言切换、数据图表、搜索筛选、案例弹窗等交互
- `assets/` — 从小组 PPT 中提取并裁掉账号区域的案例截图

## 使用和展示

双击 `index.html` 即可打开完整网站，无需安装软件、登录或联网；用 Chrome、Safari、Edge 均可。电脑/手机自适应。

课堂演示顺序建议：

1. **首页**：提出 “Do women need to earn self-love?”
2. **The puzzle**：点击 Choice / Reward / Resistance，展示同一消费行为背后的不同理由。
3. **Four findings**：点击四个研究发现，呈现案例截图或文本及解释。
4. **Evidence lab**：筛选 `REWARD`、`NORM`、`RESIST`，点击任一案例查看中英文本与代码判断。
5. **Methods / Conclusion**：讲研究方法与局限性，回扣核心问题。

## GitHub Pages 发布（获得可以交给老师的公开网址）

1. 登录 GitHub，新建一个 **Public** repository，例如 `self-love-research`。
2. 将本文件夹中的 `index.html`、`styles.css`、`script.js`、`data.js` 和整个 `assets` 文件夹**直接放在仓库根目录**。不要只上传 ZIP 包。
3. 打开仓库 **Settings → Pages**，选择 **Deploy from a branch**，分支选择 **main**，文件夹选择 **/(root)**，点击 Save。
4. GitHub Pages 部署完成后，页面会显示正式的 `https://你的用户名.github.io/self-love-research/` 形式的链接。只有仓库发布成功之后，这个地址才会真实可访问。
5. 分享这个链接给老师。访客只可以查看、筛选和交互，不可以通过网页修改源码。

## 数据说明（建议提交前全组确认）

网站遵循上传的 19 行编码表与 PPT 方法页的划分：**19 条已记录、8 条主样本、3 条对照、其他 8 条为筛选/补充/待审材料**。同一篇可能命中多项编码，频次不是百分比，不能作为平台总体结论。

- **PPT 的一处矛盾**：方法页写 8 条 main samples、3 条 comparison，后面 Limitations 页却写 `N = 18 main posts`；网站暂以编码表可核实的 8 条主样本为准。
- **案例和编码应以 Excel 为准**：S19 是明确 AGENCY 样本；S10 有明确 REWARD 话语，但 AGENCY 在表中为“不明确”，因此网页不把 S10 算作已确认的 AGENCY。
- **第二编码员复核尚未完成**：Excel 的「还差什么」页将交叉编码列为未完成，网页不会声称已经完成 reliability check。
- **部分数据仍为暂定**：S08 标为初步 WORTH；S05/S09 的完整内容、个别检索元数据及商业标识需要进一步核实。S18 为商业推广材料，不纳入 8 条主样本。
- **方法上遵循“有明确文字证据才编码”**。S07 表里 EMOTION 有勾，但旅行短句没有体现“通过购买修复情绪”；网页没有把这条计为确认的 EMOTION 证据。
- **截图隐私**：从 PPT 提取的部分截图已裁去明显用户头像及账号区域，但请在公开上传之前再次人工检查内容是否符合课程及平台引用要求。建议保留研究用途、匿名和出处说明。
- **照片只用来佐证对应案例**。S19 没有对应 PPT 截图，因此使用文字设计而不是虚构图像。截图大多只保留 PPT 可见的部分，不能替代完整原文。
- **文献**：参考文献文字来自小组 PPT，网站未对所列书目信息进行独立外部核查。

## 简单修改

- 修改标题、正文、翻译：编辑 `script.js` 中 `dict` 对应键。英文 `en`，中文 `zh`。
- 修改样本标题、引文、状态或编码：编辑 `data.js` 中的 `cases` 列表。状态仅使用 `main`、`comparison`、`screened`；编码填写数组，例如 `['REWARD','EMOTION']`。
- 修改颜色和设计：编辑 `styles.css` 顶部的 `:root` 变量。

本网站使用原生 HTML、CSS、JavaScript，无外部脚本或第三方图片服务。所有样本都已匿名化显示，不含可公开访问的创作者原链接。
